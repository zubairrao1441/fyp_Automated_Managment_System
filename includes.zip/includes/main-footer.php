<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo date("Y") ?> <a href="https://umt.edu.pk/" target="_blank">University of management and technology</a>.</strong> All rights reserved.
</footer>