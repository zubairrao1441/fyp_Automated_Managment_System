<?php
	include("includes.php");
?>

	<body>
		<div class="panel panel-default">
		  <div class="panel-heading">Login</div>
		  <div class="panel-body">
			<button type="button" class="btn btn-default btn-lg">
			  <span class="glyphicon glyphicon-star" aria-hidden="true"></span> Star
			</button>
		  </div>
		</div>
		
	</body>
</html>