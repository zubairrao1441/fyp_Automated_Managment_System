<section class="content-header">
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active"><?php echo $subtitle;?></li>
  </ol><br/>
  <h1><?php echo $subtitle;?></h1>

</section>
