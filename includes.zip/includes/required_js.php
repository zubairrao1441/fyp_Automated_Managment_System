
<!-- REQUIRED JAVASCRIPTS -->

<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- SweetAlert -->
<script src="plugins/sweet-alert/sweetalert.min.js"></script>
<!-- Pace Page -->
<script src="plugins/pace/pace.min.js"></script>
<!-- Bootstrap Validator -->
<script src="plugins/bootstrap-validator/validator.min.js"></script>



