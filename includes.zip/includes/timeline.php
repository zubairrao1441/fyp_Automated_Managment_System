
             <ul class="timeline">
            <!-- timeline time label -->
            <li class="time-label">
                  <span class="bg-red">
                    November,2014
                  </span>
            </li>
            <!-- /.timeline-label -->
            <!-- timeline item -->
            <li>
              <i class="fa fa-envelope bg-blue"></i>

              <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                <h3 class="timeline-header"><a href="#">Muhammad Saud Khan </a> sent you an email</h3>

                <div class="timeline-body">
                <p>AoA,Date for Open House (Fall 2015) has been finalized. All Part-01 project groups are required to participate in this activity (Friday, 4th December 2015 (9:00AM-1:00PM)).</p>
                <ul>
                	<li>All groups (including every member of the team) are required to arrive as early as possible and setup their stalls by 9:00AM.</li>....
                	                                      
                </ul>


                </div>
                <div class="timeline-footer">
                  <a class="btn btn-primary btn-xs">Read more</a>
                  <a class="btn btn-danger btn-xs">Delete</a>
                </div>
              </div>
            </li>
            <!-- END timeline item -->
            <!-- timeline item -->
            <li>
              <i class="fa fa-user bg-aqua"></i>

              <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                <h3 class="timeline-header no-border"><a href="#">Zeeshan Sabir</a> accepted your supervisor request</h3>
              </div>
            </li>
            <!-- END timeline item -->
           
            <!-- timeline time label -->
            <li class="time-label">
                  <span class="bg-green">
                    October 04, 2014
                  </span>
            </li>
            <!-- /.timeline-label -->
            <!-- timeline item -->
            <li>
              <i class="fa fa-info bg-yellow"></i>

              <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i>3:30</span>

                <h3 class="timeline-header"><a href="#">You </a>have created group with <a href="#">Muhammad Muneeb </a> and <a href="#">Bilal Hassan</a></h3>

                <div class="timeline-body">
                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean bibendum nulla ut libero ornare tempor. Sed vel diam elit. Maecenas nibh dolo
                </div>
                <div class="timeline-footer">
                  <a class="btn btn-warning btn-flat btn-xs">View Members</a>
                </div>
              </div>
            </li>
            <!-- END timeline item -->
            <li>
              <i class="fa fa-clock-o bg-gray"></i>
            </li>
          </ul>
          